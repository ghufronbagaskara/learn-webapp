<?php

declare(strict_types=1);

return [
  'driver' => env('SCOUT_DRIVER', 'database'),

  'prefix' => env('SCOUT_PREFIX', ''),

  'queue' => env('SCOUT_QUEUE', false),

  'after_commit' => false,

  'chunk' => [
    'searchable' => 500,
    'unsearchable' => 500,
  ],

  'soft_delete' => false,
];
