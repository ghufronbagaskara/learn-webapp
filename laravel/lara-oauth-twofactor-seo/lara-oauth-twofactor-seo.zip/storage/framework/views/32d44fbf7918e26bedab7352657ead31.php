

<div <?php echo e($attributes->class('flex-1')); ?> data-flux-spacer></div>
<?php /**PATH D:\kowlej\programming\web-app\basic\laravel\lara-oauth-twofactor-seo\vendor\livewire\flux\src/../stubs/resources/views/flux/spacer.blade.php ENDPATH**/ ?>