<?php

use App\Concerns\PasswordValidationRules;
use App\Livewire\Actions\Logout;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

return new class extends Component {
    use PasswordValidationRules;

    public string $password = '';

    /**
     * Delete the currently authenticated user.
     */
    public function deleteUser(Logout $logout): void
    {
        $this->validate([
            'password' => $this->currentPasswordRules(),
        ]);

        tap(Auth::user(), $logout(...))->delete();

        $this->redirect('/', navigate: true);
    }

    protected function view($data = [])
    {
        return app('view')->file('D:\kowlej\programming\web-app\basic\laravel\lara-oauth-twofactor-seo\storage\framework/views/livewire/views/04e5613c.blade.php', $data);
    }
}; 