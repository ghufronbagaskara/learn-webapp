<?php

use Livewire\Component;

return new class extends Component {
    protected function view($data = [])
    {
        return app('view')->file('D:\kowlej\programming\web-app\basic\laravel\lara-oauth-twofactor-seo\storage\framework/views/livewire/views/fb90d6e2.blade.php', $data);
    }
}; 