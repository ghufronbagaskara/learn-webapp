<?php if (isset($component)) { $__componentOriginal81a506f898233b9e7d58286e6bea3c18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81a506f898233b9e7d58286e6bea3c18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::app','data' => ['title' => __('Dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dashboard'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="mx-auto grid w-full max-w-6xl gap-6 md:grid-cols-3">
        <a href="<?php echo e(route('blog.create')); ?>" class="rounded-xl border border-zinc-200 bg-white p-6 hover:border-indigo-300 dark:bg-zinc-900">
            <p class="text-sm text-zinc-500">Konten</p>
            <h2 class="mt-2 text-xl font-bold">Tulis Artikel Baru</h2>
            <p class="mt-2 text-sm text-zinc-600">Buat draft atau publikasi artikel lengkap dengan SEO metadata.</p>
        </a>

        <a href="<?php echo e(route('categories.index')); ?>" class="rounded-xl border border-zinc-200 bg-white p-6 hover:border-indigo-300 dark:bg-zinc-900">
            <p class="text-sm text-zinc-500">Klasifikasi</p>
            <h2 class="mt-2 text-xl font-bold">Kelola Kategori</h2>
            <p class="mt-2 text-sm text-zinc-600">Atur kategori artikel agar navigasi konten lebih rapi.</p>
        </a>

        <a href="<?php echo e(route('comments.index')); ?>" class="rounded-xl border border-zinc-200 bg-white p-6 hover:border-indigo-300 dark:bg-zinc-900">
            <p class="text-sm text-zinc-500">Moderasi</p>
            <h2 class="mt-2 text-xl font-bold">Review Komentar</h2>
            <p class="mt-2 text-sm text-zinc-600">Approve atau tolak komentar sebelum tampil di artikel.</p>
        </a>

        <div class="rounded-xl border border-zinc-200 bg-white p-6 md:col-span-3 dark:bg-zinc-900">
            <h2 class="text-xl font-bold">Status Platform</h2>
            <p class="mt-2 text-sm text-zinc-600">
                OAuth, 2FA TOTP, SEO metadata, sitemap, komentar Livewire, dan newsletter telah terintegrasi dalam platform ini.
            </p>
            <a href="<?php echo e(route('blog.index')); ?>" class="mt-4 inline-block rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-500">
                Buka Halaman Blog
            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $attributes = $__attributesOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $component = $__componentOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__componentOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php /**PATH D:\kowlej\programming\web-app\basic\laravel\lara-oauth-twofactor-seo\resources\views/dashboard.blade.php ENDPATH**/ ?>