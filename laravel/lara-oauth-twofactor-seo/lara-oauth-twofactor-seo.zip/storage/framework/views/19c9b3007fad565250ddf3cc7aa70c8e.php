<section class="space-y-4 rounded-xl border border-zinc-200 p-4">
    <h3 class="text-base font-semibold">Two-Factor Authentication (TOTP)</h3>
    <p class="text-sm text-zinc-600">
        Kode OTP 2FA berasal dari aplikasi authenticator (Google Authenticator, Microsoft Authenticator, Authy), bukan dari email.
    </p>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
        <p class="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700"><?php echo e(session('status')); ?></p>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isEnabled): ?>
        <p class="text-sm text-zinc-600">2FA saat ini aktif untuk akun Anda.</p>
        <button wire:click="disable" type="button" class="rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white hover:bg-red-500">
            Nonaktifkan 2FA
        </button>
    <?php else: ?>
        <p class="text-sm text-zinc-600">Aktifkan 2FA untuk menambah keamanan akun Anda.</p>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($qrCodeInline): ?>
            <div class="rounded-lg border border-zinc-200 bg-white p-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(str_starts_with($qrCodeInline, 'data:image')): ?>
                    <img src="<?php echo e($qrCodeInline); ?>" alt="QR Code 2FA" class="mx-auto" />
                <?php else: ?>
                    <?php echo $qrCodeInline; ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($manualSecret): ?>
                <div class="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800">
                    Jika QR tidak tampil atau tidak bisa discan, masukkan secret ini secara manual di aplikasi authenticator:
                    <div class="mt-1 break-all rounded bg-white px-2 py-1 font-mono text-xs text-zinc-800"><?php echo e($manualSecret); ?></div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($otpauthUrl): ?>
                <p class="text-xs text-zinc-500 break-all">OTP URI: <?php echo e($otpauthUrl); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div>
                <label class="mb-2 block text-sm font-medium">Masukkan kode OTP</label>
                <input wire:model="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="8" placeholder="123456" class="w-full rounded-lg border border-zinc-300 px-3 py-2 text-sm" />
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <button wire:click="confirm" type="button" class="rounded-lg bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-500">
                Konfirmasi 2FA
            </button>
        <?php else: ?>
            <button wire:click="setup" type="button" class="rounded-lg bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-500">
                Mulai Setup 2FA (Generate Secret)
            </button>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</section>
<?php /**PATH D:\kowlej\programming\web-app\basic\laravel\lara-oauth-twofactor-seo\resources\views/livewire/two-factor-setup.blade.php ENDPATH**/ ?>