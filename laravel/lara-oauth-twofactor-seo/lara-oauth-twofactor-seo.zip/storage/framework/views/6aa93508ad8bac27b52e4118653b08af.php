

<nav <?php echo e($attributes->class('flex flex-col overflow-visible min-h-auto')); ?> data-flux-sidebar-nav>
    <?php echo e($slot); ?>

</nav>
<?php /**PATH D:\kowlej\programming\web-app\basic\laravel\lara-oauth-twofactor-seo\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php ENDPATH**/ ?>