<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('comments', function (Blueprint $table) {
      $table->id();
      $table->foreignId('blog_post_id')->constrained()->cascadeOnDelete();
      $table->foreignId('user_id')->constrained()->cascadeOnDelete();
      $table->foreignId('parent_id')->nullable()->constrained('comments')->nullOnDelete();
      $table->text('content');
      $table->boolean('is_approved')->default(false);
      $table->softDeletes();
      $table->timestamps();

      $table->index('blog_post_id');
      $table->index('parent_id');
      $table->index('is_approved');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('comments');
  }
};
