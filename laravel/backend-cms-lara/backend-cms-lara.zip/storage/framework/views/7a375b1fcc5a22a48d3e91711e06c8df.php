<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['seo' => null, 'title' => null, 'description' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['seo' => null, 'title' => null, 'description' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $metaTitle = $seo?->meta_title ?? $title ?? config('app.name');
    $metaDescription = $seo?->meta_description ?? $description ?? '';
    $ogTitle = $seo?->og_title ?? $metaTitle;
    $ogDescription = $seo?->og_description ?? $metaDescription;
    $ogImage = $seo?->og_image ? asset('storage/'.$seo->og_image) : asset('images/og-default.png');
    $canonical = $seo?->canonical_url ?? url()->current();
?>

<title><?php echo e($metaTitle); ?></title>
<meta name="description" content="<?php echo e($metaDescription); ?>">
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($seo?->meta_keywords): ?>
    <meta name="keywords" content="<?php echo e($seo->meta_keywords); ?>">
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<link rel="canonical" href="<?php echo e($canonical); ?>">

<meta property="og:title" content="<?php echo e($ogTitle); ?>">
<meta property="og:description" content="<?php echo e($ogDescription); ?>">
<meta property="og:image" content="<?php echo e($ogImage); ?>">
<meta property="og:url" content="<?php echo e($canonical); ?>">
<meta property="og:type" content="website">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e($ogTitle); ?>">
<meta name="twitter:description" content="<?php echo e($ogDescription); ?>">
<meta name="twitter:image" content="<?php echo e($ogImage); ?>">
<?php /**PATH D:\kowlej\programming\web-app\basic\laravel\backend-cms-lara\resources\views/components/seo-head.blade.php ENDPATH**/ ?>