<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => ['seo' => $seo ?? null,'pageTitle' => $pageTitle ?? 'Home']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo ?? null),'page-title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pageTitle ?? 'Home')]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <section class="grid gap-6 lg:grid-cols-3">
        <article class="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h1 class="text-2xl font-semibold text-gray-900 tracking-tight"><?php echo e($page?->title ?? 'Welcome to Maxian Corp'); ?></h1>
            <div class="mt-4 prose prose-sm max-w-none text-gray-700">
                <?php echo $page?->content ?? '<p>Build your corporate website and content operations from one dashboard.</p>'; ?>

            </div>
        </article>

        <aside class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h2 class="text-base font-medium text-gray-700">Quick Links</h2>
            <nav class="mt-4 space-y-2">
                <a href="<?php echo e(route('blog.index')); ?>" class="block text-sm text-indigo-600 hover:text-indigo-700">Read our blog</a>
                <a href="<?php echo e(route('login')); ?>" class="block text-sm text-indigo-600 hover:text-indigo-700">Open admin panel</a>
            </nav>
        </aside>
    </section>

    <section class="mt-8 bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <header class="flex items-center justify-between">
            <h2 class="text-2xl font-semibold text-gray-900 tracking-tight">Latest Articles</h2>
            <a href="<?php echo e(route('blog.index')); ?>" class="inline-flex items-center gap-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 text-sm font-medium px-4 py-2 rounded-lg transition">See all</a>
        </header>

        <div class="mt-6 grid gap-4 md:grid-cols-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article class="border border-gray-100 rounded-xl p-4" <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'home-post-'.e($post->id).''; ?>wire:key="home-post-<?php echo e($post->id); ?>">
                    <h3 class="text-base font-medium text-gray-900"><?php echo e($post->title); ?></h3>
                    <p class="mt-2 text-sm text-gray-500"><?php echo e($post->excerpt); ?></p>
                    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="mt-4 inline-block text-sm text-indigo-600 hover:text-indigo-700">Read more</a>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <article class="md:col-span-3 text-center py-10 text-gray-400">No records found.</article>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH D:\kowlej\programming\web-app\basic\laravel\backend-cms-lara\resources\views/pages/home.blade.php ENDPATH**/ ?>