<?php
    $pivotPayload = json_encode([
        'startDate' => $startDate,
        'endDate' => $endDate,
        'status' => $status,
        'pivotRows' => $pivotRows,
    ]);
?>

<div
    id="pivot-report-page"
    wire:init="initLoad"
    class="min-h-screen bg-slate-50 p-6 space-y-6"
    data-payload="<?php echo e($pivotPayload); ?>"
>
    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h1 class="font-semibold text-slate-800 tracking-tight text-2xl">Pivot Reporting</h1>
            <p class="text-sm text-slate-600">Interactive pivot analysis for category and month aggregation.</p>
        </div>

        <div class="inline-flex items-center gap-2">
            <a href="<?php echo e(route('reports.sales')); ?>" class="inline-flex items-center rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">
                Sales Report
            </a>
            <a href="<?php echo e(route('reports.pivot')); ?>" class="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white">
                Pivot Report
            </a>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
        <h2 class="text-base font-semibold text-slate-800 mb-4">Filters</h2>
        <div class="flex flex-wrap gap-3 items-end">
            <div class="flex flex-col gap-1" wire:ignore>
                <label for="pivotDateRange" class="text-xs font-medium text-slate-500 uppercase tracking-wide">Date Range</label>
                <input
                    id="pivotDateRange"
                    type="text"
                    placeholder="YYYY-MM-DD to YYYY-MM-DD"
                    class="rounded-lg border border-slate-200 text-sm px-3 py-2 min-w-65 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
                />
            </div>

            <div class="flex flex-col gap-1 min-w-45" wire:ignore>
                <label for="pivotStatusFilter" class="text-xs font-medium text-slate-500 uppercase tracking-wide">Status</label>
                <select id="pivotStatusFilter" class="rounded-lg border border-slate-200 text-sm bg-white px-3 py-2">
                    <option value="">All</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option value="<?php echo e($statusOption); ?>" <?php if($statusOption === $status): echo 'selected'; endif; ?>>
                            <?php echo e(str($statusOption)->headline()); ?>

                        </option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            </div>

            <button wire:click="resetFilters" type="button" class="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">
                Reset
            </button>
        </div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col gap-1" <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'pivot-summary-'.e($index).''; ?>wire:key="pivot-summary-<?php echo e($index); ?>">
                <span class="text-xs font-medium text-slate-500 uppercase tracking-wide">
                    <?php echo e($stat['label']); ?>

                </span>
                <span class="font-mono text-2xl font-bold text-slate-900">
                    <?php echo e($stat['value']); ?>

                </span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($stat['trend']) && ! is_null($stat['trend'])): ?>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'text-xs font-medium px-2 py-0.5 rounded-full w-fit',
                        'bg-emerald-50 text-emerald-600' => $stat['trend'] > 0,
                        'bg-red-50 text-red-500' => $stat['trend'] < 0,
                        'bg-slate-100 text-slate-600' => $stat['trend'] === 0.0,
                    ]); ?>">
                        <?php echo e($stat['trend'] >= 0 ? '▲' : '▼'); ?> <?php echo e(abs($stat['trend'])); ?>%
                    </span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 p-6">
        <h2 class="text-base font-semibold text-slate-800 mb-4">What-If Analysis (Pivot)</h2>
        <div id="pivotOnlyOutput" class="overflow-auto"></div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.ReportPivotPage?.boot($wire);
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\kowlej\programming\web-app\basic\laravel\report-data-lara\resources\views/livewire/reports/pivot-report.blade.php ENDPATH**/ ?>